Drag sketch.js onto your P5 editor ap icon to open and run it
